# LlamaIndex basic brand kit

Logo, colors and type for the current brand. Tokens are also in `tokens.css`.

## Logo

| File | Use |
|---|---|
| `logo/llamaindex-lockup.svg` / `.png` | Icon + wordmark, light backgrounds |
| `logo/llamaindex-lockup-on-dark.svg` / `.png` | Icon + wordmark, dark backgrounds (no tile, white wordmark) |
| `logo/llamaindex-mark.svg` / `.png` | Icon (avatars, favicons, small spaces) |
| `logo/llamaindex-construction.svg` / `.png` | Construction grid, for reference |

On light backgrounds the llama sits on a black tile; on dark backgrounds it stands on its own, without the tile. It always uses the logo gradient, left to right (head to tail): orange #FEA13C → pink #FE80C6 → purple #7391FD → blue #63DFFA.

Construction, where u = tile width ÷ 12:

- Llama: 9u tall, centred in the tile.
- Wordmark: cap height 8u, centred vertically on the tile.
- Gap between tile and wordmark: 5u.
- Clear space: 3u on all sides.

Don't recolor, redraw, stretch or rearrange the logo. On light backgrounds, don't place the wordmark without the tile.

## Colors

### Neutrals

| Name | Hex | Use |
|---|---|---|
| Black | #000000 | Text, buttons, logo tile, selected states |
| White | #FFFFFF | Page backgrounds, cards, panels |
| Off White | #FAFAF9 | Alternate section backgrounds |
| Light Grey | #F4F4F1 | UI surfaces, inactive tabs, bar tracks |
| Mid Grey | #D9D9D5 | Borders, dividers, grid, neutral bars |
| Dark Grey | #939393 | Secondary text, labels, line numbers |

### Brand colors

The same four colors in three levels, always ordered orange → pink → purple → blue.

| | Orange | Pink | Purple | Blue | Use |
|---|---|---|---|---|---|
| Light | #FCD8B0 | #FCCBE6 | #C6D1FB | #C0F0F9 | Backgrounds |
| Mid | #FDBB73 | #FDA3D5 | #9AAFFC | #8FE7FA | Graphic elements (bars, bands, fills) |
| Mid+ | #FEA13C | #FE80C6 | #7391FD | #63DFFA | Small accents only, matches the logo |

Mid+ colors are never used as large fills. Black is never used in patterns or effects; use Mid Grey or Dark Grey there.

### Logo gradient

`linear-gradient(90deg, #FEA13C 0%, #FE80C6 33.33%, #7391FD 66.67%, #63DFFA 100%)`, token `--logo-gradient`.

Besides the logo, the gradient is used as an accent: to mark, highlight or underline something, or as a stroke. Keep it thin and small.

- Use for: strokes around an important illustration or card element (e.g. a highlighted number), underlines, thin dividers, small markers for an active or highlighted item.
- Don't use for: backgrounds, large shapes, panels or big blocks of color.
- Always orange → pink → purple → blue, never reordered.

## Typography

All three typefaces are used in Regular (400) only.

| Role | Typeface | Web | Desktop / Figma |
|---|---|---|---|
| Headlines | Redaction 20 | `fonts/web/Redaction20-Regular.woff2` | `fonts/desktop/Redaction20-Regular.otf` |
| Body | Geist | `fonts/web/Geist-Regular.woff2` | `fonts/desktop/Geist-Regular.ttf` |
| Accent (labels, tags, code) | Geist Mono | `fonts/web/GeistMono-Regular.woff2` | `fonts/desktop/GeistMono-Regular.ttf` |

Use the `web` files on websites and the `desktop` files to install the fonts in Figma or other apps.

Fallbacks: Georgia for Redaction 20, system sans-serif for Geist, system monospace for Geist Mono.
